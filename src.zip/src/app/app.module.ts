import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { Arquivo } from './arquivo';

@NgModule({
  declarations: [
    Arquivo
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [Arquivo]
})
export class AppModule { }
