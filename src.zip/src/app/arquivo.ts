import  { Component } from '@angular/core';
@Component({
  selector : 'app-root',
  templateUrl : './app.component.html',
  styleUrls:  ['./app.component.css']
})

export  class  Arquivo  {
    title = 'Trabalho';
    alunos : Array<any>; constructor () {
      this.alunos  =  [
        {  Nome : 'WELLINGTON FARIAS DE SOUSA', RU: '3305060', CURSO: 'CST ANÁLISE E DESENVOLVIMENTO DE SISTEMAS - DISTÂNCIA', Nascimento :'21/07/1975' },
        {  Nome : 'JOSE FARIAS DE SOUSA', RU: '3305061', CURSO: 'CST ANÁLISE E DESENVOLVIMENTO DE SISTEMAS - DISTÂNCIA', Nascimento :'21/07/1978' },
        {  Nome : 'MARIA FARIAS DE SOUSA', RU: '3305062', CURSO: 'CST ANÁLISE E DESENVOLVIMENTO DE SISTEMAS - DISTÂNCIA', Nascimento :'21/07/1965' },
        {  Nome : 'JOAO FARIAS DE SOUSA', RU: '3305063', CURSO: 'CST ANÁLISE E DESENVOLVIMENTO DE SISTEMAS - DISTÂNCIA', Nascimento :'21/06/1975' },
        {  Nome : 'JUCA FARIAS DE SOUSA', RU: '3305064', CURSO: 'CST ANÁLISE E DESENVOLVIMENTO DE SISTEMAS - DISTÂNCIA', Nascimento :'20/07/1900' },
      ];
    }
}
